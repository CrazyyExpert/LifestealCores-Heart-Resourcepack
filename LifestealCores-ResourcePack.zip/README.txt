LifestealCores Resource Pack - by CrazyyExpert
Heart item uses custom-model-data 1 (set items.heart.custom-model-data: 1 in the plugin config.yml).
